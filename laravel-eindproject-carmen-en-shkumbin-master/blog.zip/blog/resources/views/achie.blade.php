@extends('layout')

<?php ?>
@section('title','Blogs')

@section('content')
    <h1>Blogs</h1>
    @foreach($db as $data)
        <h2>{{$data->title}}</h2>
        <p>{{$data->content}}</p>
    @endforeach
@endsection




















































































