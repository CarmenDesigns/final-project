<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css" integrity="sha384-9gVQ4dYFwwWSjIDZnLEWnxCjeSWFphJiwGPXr1jddIhOegiu1FwO5qRGvFXOdJZ4" crossorigin="anonymous">
    <title>Blogs - @yield('title')</title>
</head>
<body>

    <ul class="nav justify-content-center">
        <li class="nav-item">
            <a class="nav-link active" href={{'http://127.0.0.1:8000/blogs'}}>Home</a>
        </li>
        <li>
            <a class="nav-link" href={{'http://127.0.0.1:8000/blogs/create'}}>Create</a>
        </li>
        {{--<li class="nav-item">--}}
            {{--<a class="nav-link" href={{'../blogs/edit'}}>Update</a>--}}
        {{--</li>--}}
    </ul>


    @if ($errors->any())
        <div class="alert alert-danger">
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif
@yield('content')
</body>
