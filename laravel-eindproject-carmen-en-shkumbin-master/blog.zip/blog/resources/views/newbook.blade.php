@extends('layout')


@section('content')




    {!! Form::open(['url' => 'books','method'=>'POST']) !!}

{!! Form::token() !!}
{!! Form::label('title','naam:') !!}
{!! Form::text('title') !!}
{!! Form::label('content','inhoud:') !!}
{!! Form::textarea('content') !!}
{!! Form::submit('Create the Blog!', array('class' => 'btn btn-primary')) !!}
{!! Form::close() !!}

    @endsection