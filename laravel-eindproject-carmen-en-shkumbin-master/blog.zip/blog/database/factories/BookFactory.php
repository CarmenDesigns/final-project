<?php

use Faker\Generator as Faker;

$factory->define(App\Book::class, function (Faker $faker) {
    return [
        'name' => $faker->sentence(5),
        'created_at' => $faker->dateTime(),
        'updated_at' => $faker->dateTime()
    ];
});
