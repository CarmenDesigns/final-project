<?php

use Faker\Generator as Faker;

$factory->define(App\Blog::class, function (Faker $faker) {
    return [
        'title' => $faker->sentence(5),
        'content' => $faker->sentence(100),
        'created_at' => $faker->dateTime()

    ];
});
