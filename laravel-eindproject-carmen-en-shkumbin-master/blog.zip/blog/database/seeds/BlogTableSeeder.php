<?php

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class BlogTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
//        DB::table('blog')->insert([
//            'title' => str_random(30),
//            'content' => str_random(400),
//        ]);
        factory(App\Blog::class, 500)->create();

    }
}
