<?php $__env->startSection('title','Update'); ?>

<?php $__env->startSection('content'); ?>
    <?php if(isset($succeed) && $succeed[0] == true): ?>
        <div class="alert alert-success">
            Blog <?php echo e($succeed[1]); ?> succesvol upgedate!
        </div>
    <?php endif; ?>
    <h2><?php echo e($blog->title); ?></h2>
    <p><?php echo e($blog->content); ?></p>

    <?php echo Form::open(['url' => "blogs/$blog->id",'method'=>'POST']); ?>


    <?php echo Form::token(); ?>

    <?php echo e(method_field('PATCH')); ?>

    <?php echo Form::label('title','naam:'); ?>

    <?php echo Form::text('title'); ?>

    <?php echo Form::label('content','inhoud:'); ?>

    <?php echo Form::textarea('content'); ?>

    <?php echo Form::submit('Update the Blog!', array('class' => 'btn btn-primary')); ?>

    <?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>