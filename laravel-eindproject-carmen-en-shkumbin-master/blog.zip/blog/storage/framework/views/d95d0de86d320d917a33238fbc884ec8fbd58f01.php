<?php ?>
<?php $__env->startSection('title',$blog->title); ?>


<?php $__env->startSection('content'); ?>
    <h2><?php echo e($blog->title); ?></h2>
    <p><?php echo e($blog->content); ?></p>
    <a class="fa fa-pencil" href="http://127.0.0.1:8000/blogs/<?php echo e($blog->id); ?>/edit">edit</a>
    <?php echo Form::open(['url' => "blogs/$blog->id",'method'=>'POST']); ?>

    <?php echo Form::token(); ?>

    <?php echo e(method_field('DELETE')); ?>

    <button type="submit" id="completed-task" class="fabutton">
        <i class="fa fa-trash">delete</i>
    </button>
    <?php echo Form::close(); ?>



<style>
    .fabutton {
    background: none;
    padding: 0px;
    border: none;
    }</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('../layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>