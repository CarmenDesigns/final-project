<?php $__env->startSection('title','Create'); ?>
<?php $__env->startSection('content'); ?>

    <?php if(isset($succeed) && $succeed[0] == true): ?>
        <div class="alert alert-success">
        Blog <?php echo e($succeed[1]); ?> succesvol aangemaakt!
        </div>
    <?php endif; ?>

    <?php echo Form::open(['url' => 'blogs','method'=>'POST']); ?>


    <?php echo Form::token(); ?>

    <div class="col-12">

    <?php echo Form::label('title','naam:'); ?>

    <?php echo Form::text('title'); ?>

    <?php echo Form::label('content','inhoud:'); ?>

    <?php echo Form::textarea('content'); ?>

    <?php echo Form::submit('Create the Blog!', array('class' => 'btn btn-primary')); ?>

    <?php echo Form::close(); ?>


    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('../layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>