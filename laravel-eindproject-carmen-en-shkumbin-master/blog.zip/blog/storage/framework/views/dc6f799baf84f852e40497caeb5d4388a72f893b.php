<?php $__env->startSection('content'); ?>




    <?php echo Form::open(['url' => 'achie','method'=>'POST']); ?>


<?php echo Form::token(); ?>

<?php echo Form::label('title','naam:'); ?>

<?php echo Form::text('title'); ?>

<?php echo Form::label('content','inhoud:'); ?>

<?php echo Form::textarea('content'); ?>


<?php echo Form::close(); ?>


    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>