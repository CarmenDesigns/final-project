<?php ?>
<?php $__env->startSection('title','Blogs'); ?>

<?php $__env->startSection('content'); ?>
    <h1>Blogs</h1>
    <?php $__currentLoopData = $db; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <h2><?php echo e($data->title); ?></h2>
        <p><?php echo e($data->content); ?></p>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>





















































































<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>