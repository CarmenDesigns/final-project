<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css" integrity="sha384-9gVQ4dYFwwWSjIDZnLEWnxCjeSWFphJiwGPXr1jddIhOegiu1FwO5qRGvFXOdJZ4" crossorigin="anonymous">
    <title>Blogs - <?php echo $__env->yieldContent('title'); ?></title>
</head>
<body>

    <ul class="nav justify-content-center">
        <li class="nav-item">
            <a class="nav-link active" href=<?php echo e('http://127.0.0.1:8000/blogs'); ?>>Home</a>
        </li>
        <li>
            <a class="nav-link" href=<?php echo e('http://127.0.0.1:8000/blogs/create'); ?>>Create</a>
        </li>
        
            
        
    </ul>


    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
<?php echo $__env->yieldContent('content'); ?>
</body>
